# نسخة التسليم — الطبقة الفلسفية والمعرفة السيادية

> **المسار الثالث** · Philosophy docs · Child Journey Core  
> **التاريخ:** يوليو 2026  
> **الحالة:** Draft — غير مدمج في `main`

---

## ما هذه النسخة؟

حزمة **كاملة** لطبقة المعرفة والفلسفة التي بُنيت **بعد** مساري تواصل ومريم — **مستقلة** عن عونك الأم التشغيلية.

| يشمل | لا يشمل |
|------|---------|
| الدستور (`AUNAK_CONSTITUTION`) | كود React / API |
| فلسفة التصميم (`philosophy/`) | `Tawasul_MVP` |
| المعرفة الميدانية DK-001 → DK-010 | `Maryam_English_Island` |
| القاموس الموحد · الوحدات · الجلسات | `DELIVERY_AUNAK_CORE` |

---

## ترتيب القراءة

| # | الملف | الغرض |
|---|-------|--------|
| 1 | `docs/philosophy/000_MANIFEST.md` | دستور المكتبة الفلسفية |
| 2 | `docs/AUNAK_CONSTITUTION.md` | دستور المشروع |
| 3 | `docs/05_DECISIONS_LOG.md` | قرار A-001 Child Journey Core |
| 4 | `docs/philosophy/003_AUNAK_CORE_PHILOSOPHY.md` | المرجع الفكري الأعلى |
| 5 | `docs/domain-knowledge/DK-001` → `DK-010` | المعرفة الميدانية |
| 6 | `docs/INDEX.md` + `DOCUMENT_REGISTRY.md` | الفهرس والمعرفات |

---

## هيكل المجلد

```
DELIVERY_AUNAK_PHILOSOPHY/
├── INDEX.md                    ← هذا الملف
├── MANIFEST_PATHS.md           ← فهرس المسارات الكامل
└── docs/
    ├── 00_PROJECT_IDENTITY.md … 06_ROADMAP.md
    ├── AUNAK_CONSTITUTION.md
    ├── INDEX.md
    ├── DOCUMENT_REGISTRY.md
    ├── philosophy/             (12 ملف)
    ├── domain-knowledge/       (11 ملف)
    ├── modules/                (7 ملفات)
    ├── terminology/            (5 ملفات)
    └── sessions/               (2 ملف)
```

**إجمالي:** 47 ملف markdown

---

*AUNAK Sovereign Knowledge Layer · July 2026*
